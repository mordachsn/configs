# Changelog

### master
- to speed up the "online test" ping uses only 1 packet
- fix issue with status-right and status-left whitespace being cut out
- add ping default timeout (@mjwhitta)

### v1.0.0, 2014-10-26
- README updates
- update readme to reflect github organization changes
- linux can't display default offline icon - update it
- add "@route_to_ping" option

### v0.0.2, 2014-06-02
- bugfix: offline status icon wasn't displaying properly

### v0.0.1, 2014-06-02
- first working version
